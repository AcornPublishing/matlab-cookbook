function h = biDirErrBar(x,y,e_x,e_y)

% bidirErrBar(x,y,e_x,e_y) plots bi directional error bars and returns the
% handle to the axes for annotation
% x, y are the data vectors with n elements each. e_x and e_y are the error bars to be
% positioned at each point in xi,yi, 

errorbar(x,y,e_y); hold on;
plot(x,y,'Color',[0 0 0]);
x_lower=x-e_x; x_upper=x+e_x; 
y_lower=y-.0001*y; y_upper=y+.0001*y;
line([x_lower; x_upper],[y; y],'Color',[0 0 1]);

hold on; line([x_lower; x_lower], [y_lower; y_upper],'Color',[0 0 1]);
hold on; line([x_upper; x_upper], [y_lower; y_upper],'Color',[0 0 1]);

h = gca;
