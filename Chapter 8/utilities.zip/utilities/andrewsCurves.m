function [t curves] = andrewsCurves(dat)

% andrewscurves (X) takes
% "X" is an m X n data matrix, with m records, n variables 
% and returns a curve per data point where the dimensions of each 
% data point are treated as Fourier series coeffs
t = linspace(0,1,100);
curves = zeros(size(dat,1),length(t));

omega = 2*pi*(1:floor(size(dat,2)/2));
omegaSin = omega(1:floor(size(dat,2)/2));
omegaCos = omega(1:floor((size(dat,2)-1)/2));

for i = 1:size(dat,1)
    curves(i,:) = (dat(i,1)/sqrt(2))*ones(size(t));
    for j = 1:floor((size(dat,2)-1)/2)
        curves(i,:) =  curves(i,:)+ dat(i,j+1)*sin(omegaSin(j)*t) + dat(i,j+2)*cos(omegaCos(j)*t);
    end
    if length(omegaSin)>length(omegaCos)
        curves(i,:) =  curves(i,:)+ dat(i,end).*sin(omegaSin(end)*t);
    end
end
