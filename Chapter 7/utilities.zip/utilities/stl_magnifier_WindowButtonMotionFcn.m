%% WindowButtonMotion Function for the Figure
function stl_magnifier_WindowButtonMotionFcn(obj,event)

    %extract parameters
    userdata = get(gcbo,'userdata');
    cur_time = toc(userdata.start_time);
    curFrameNo = floor(cur_time.*userdata.FPS);
    % If this frame has not been draw yet
    if userdata.alreadyDrawn < curFrameNo 

        mag_pos = get(obj,'CurrentPoint');
        mag_pos(1) = round(size(userdata.img_rgb,2)*mag_pos(1));
        mag_pos(2) = size(userdata.img_rgb,2) - round(size(userdata.img_rgb,2)*mag_pos(2))+1;
        % The size of the part of the image to be magnified
        % The range has to be cropped in case it is outside the
        % image.
        mag_x = mag_pos(1)+[-userdata.PreMagRadius userdata.PreMagRadius];
        mag_x_cropped = min(max(mag_x, 1),userdata.size_img(2));
        mag_y = mag_pos(2)+[-userdata.PreMagRadius userdata.PreMagRadius];
        mag_y_cropped = min(max(mag_y, 1),userdata.size_img(1));
        % Take the magnified part of the image
        userdata.mag_img([mag_y_cropped(1):mag_y_cropped(2)]-mag_pos(2)+userdata.PreMagRadius+1,...
            [mag_x_cropped(1):mag_x_cropped(2)]-mag_pos(1)+userdata.PreMagRadius+1,:) = ...
            userdata.img_rgb(mag_y_cropped(1):mag_y_cropped(2),...
            mag_x_cropped(1):mag_x_cropped(2),:);

        % Show the image as twice its actual size
        set(userdata.mag_img_hdl, 'CData', userdata.mag_img, ...
        'XData', mag_pos(1)+[-userdata.MagRadius userdata.MagRadius], ...
        'YData', mag_pos(2)+[-userdata.MagRadius userdata.MagRadius]);

        % Update the object
        drawnow;
        userdata.alreadyDrawn = curFrameNo;
    end
    set(gcf,'userdata',userdata);
end