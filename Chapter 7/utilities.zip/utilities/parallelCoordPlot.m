function parallelCoordPlot(X,normalize, groupIndex,labl,legendLabel,varargin)

% parallelCoordPlot(X,normalize, groupIndex,labl,legendLabel,varargin)
% produces parallel coordinate plots. The input parameter
% "X" is an m X n data matrix, with m records, n variables 
% "normalize" is a boolean variable that controls the normalization of each
% data dimension between 01 and 1
% "groupIndex" can which of the n variables should you group by for
% coloring purposes; or provide an array of size m x 1 with labels 
% to use for grouping.
% "labl" is an array of strings with variable names (data dimension names) to be 
% used as x tick labels
% "legendLabel" is an array of strings with labels to use for legend
% entries
% the last argument is oprional and takes a custom color map definition

% build up the legend as you peruse the data
leg = {};

% normalize data if so indicated
if normalize
    for i = 1:size(X,2)
        Y(:,i) = X(:,i)./max(X(:,i));
    end
else
    Y = X;
end

% use thw predefined colormap summer
if ~isempty(varargin)
    colorMat = varargin{1};
else
    colorMat = colormap;
end

% select distinct colors to use for the group indicated, depending on
% number of unique values it has
if length(groupIndex)==1
    k = unique(X(:,groupIndex));
else
    k=find(unique(groupIndex));
end
colorIndices = floor(linspace(1,length(colorMat),length(k)));

for j = 1:length(k)    
    
    % Draw the lines for each record between the ith and (i+1)th variable 
    % in the chosen color for each group.
    if length(groupIndex)==1
        r = find(X(:,groupIndex)==k(j));
    else
        r = find(groupIndex==k(j));
        r = r';
    end
    for i = 1:size(X,2)-1 
        if i==1
            hLines{j} = line([(i)*ones(size(r,1),1) (i+1)*ones(size(r,1),1)]',[Y(r,i) Y(r,i+1)]','Color',colorMat(colorIndices(j),:),'linewidth',1.5);        
        else
            % For each set of lines drawn (except for those between the (n-1)th 
            % and nth variable), set the set its �IconDisplayStyle� property to off.
            try
            offLines{j}  = line([(i)*ones(size(r,1),1) (i+1)*ones(size(r,1),1)]',[Y(r,i) Y(r,i+1)]','Color',colorMat(colorIndices(j),:),'linewidth',1.5);        
            set(cell2mat(get(cell2mat(get(offLines{j},'Annotation')),'LegendInformation')), 'IconDisplayStyle','off'); 
            catch
                set(get(get(offLines{j},'Annotation'),'LegendInformation'), 'IconDisplayStyle','off'); 
            end
        end
    end
    % For the set of lines between the (n-1)th and nth variable, 
    % assign those as children to a hggroup. 
    hGroup{j} = hggroup;
    set(hLines{j},'Parent', hGroup{j});
    
    % Set the �IconDisplayStyle� property to �on� for each of the hggroup objects. 
    set(get(get(hGroup{j},'Annotation'),'LegendInformation'),'IconDisplayStyle','on'); 
    % Build up one legend entry for each hggroup object 
    if length(groupIndex)==1
        leg{j} = [labl{groupIndex} '=' legendLabel{k(j)}];
    else
        leg{j} = ['=' legendLabel{k(j)}];
    end
end
%annotate with ticklabels and legend
set(gca,'xtick',1:size(X,2),'xticklabel',labl,'Fontsize',12);
rotateXLabels( gca(), 45 );
legend(leg,'Fontsize',14,'position',[0.7881    0.0810    0.1747    0.8768]); %0.5698    0.0350    0.4090    0.2022]);

