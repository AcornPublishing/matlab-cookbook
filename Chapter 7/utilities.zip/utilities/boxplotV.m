function [lowerQuartile medianv upperQuartile upperOuter lowerInner outliers] =  boxplotV(data, labels)

%boxplotV Generates the five parameter distributional summary for drawing boxplots
% Usage:
% [lowerQuartile medianv upperQuartile upperOuter lowerInner outliers] = boxplotV(data, labels)
% takes the two one dimensional vectors DATA and LABELS. 
% Each data point in the DATA vector has a label specified in the LABELS vector.  
% For each group of data points, identified by entries with the same value of labels, 
% the function generates its lower Quartile, upper Quartile, median, 
% upper outer value, lower outer value abd a list of outliers. 


NGroups = unique(labels);
for i = 1:length(NGroups)
    % query out the data for each cancer type
    dataThisGeneThisCancer = sort(data(find(labels==i)));
    % generate the 5 parameter summary and outliers list, if any
    lowerQuartile(i) = prctile(dataThisGeneThisCancer,25);
    medianv(i) = prctile(dataThisGeneThisCancer,50);
    upperQuartile(i) = prctile(dataThisGeneThisCancer,75);
    upperOuter(i)  = dataThisGeneThisCancer(max(find(dataThisGeneThisCancer<upperQuartile(i)+1.5*(upperQuartile(i)-lowerQuartile(i)))));
    lowerInner(i)  = dataThisGeneThisCancer(min(find(dataThisGeneThisCancer>lowerQuartile(i)-1.5*(upperQuartile(i)-lowerQuartile(i)))));
    outliers(i).mat = dataThisGeneThisCancer(find(dataThisGeneThisCancer>upperOuter(i) | dataThisGeneThisCancer < lowerInner(i))); 
end