function scatterPlotSmooth2D(xx,yy,sigma,gridSize)

% scatterPlotSmooth2D(xx,yy,sigma,gridSize) takes the x and y data vectors, 
% a sigma value for the Gaussians, and a grid size on 
% which to compute the scatter plot smooth, as inputs. 
% Essentially, a fine uniform grid (per argument) is chosen for representing the data
% At each physical data point, a Gaussian distribution with a certain spread 
% centered at that point, is computed; the sum of all the Gaussians is computed on the fine data grid. 
% This represents the smoothed version of the scatter plot (the smoothing parameter in this algorithm 
% is the spread assumed for the Gaussian functions).

% choose a colormap
colormap(cool);

% declare the gridx=linspace(min(xx),max(xx),gridSize);
x=linspace(min(xx),max(xx),gridSize);
y=linspace(min(yy),max(yy),gridSize);
gridEval = zeros(length(x)-1,length(y)-1);

% calculate the gaussian function at each point
for i = 1:length(x)-1
    for j = 1:length(y)-1
    %calculate a Gaussian function on the grid with each point in the center and add them up
        gridEval(j,i) = gridEval(j,i) + sum(exp(-(((x(i)-xx).^2)./(2*sigma.^2) + ((y(j)-yy).^2)./(2*sigma.^2))));       
    end
end

% surface plot the data
surf((x(1:end-1)+ x(2:end))/2,(y(1:end-1)+y(2:end))/2,gridEval); view(2); shading interp;
axis([min(xx),max(xx) min(yy),max(yy)]);
h1 = gca; % save the handle to current axis so you can draw a box around it later

% add annotations
title(['Scatter plot smooth, sigma = ' num2str(sigma) ', on a ' num2str(gridSize) ' x' num2str(gridSize) ' grid'],'Fontsize',12);
xlabel('x','Fontsize',12);
ylabel('y','Fontsize',12);

% add a colorbar
h=colorbar;
axes(h);ylabel('Intensity');

% put a border around the graph with black lines
axes(h1);
line(get(gca,'xlim'),repmat(min(get(gca,'ylim')),1,2),'color',[0 0 0],'linewidth',1);
line(get(gca,'xlim'),repmat(max(get(gca,'ylim')),1,2),'color',[0 0 0],'linewidth',2);
line(repmat(min(get(gca,'xlim')),1,2),get(gca,'ylim'),'color',[0 0 0],'linewidth',2);
line(repmat(max(get(gca,'xlim')),1,2),get(gca,'ylim'),'color',[0 0 0],'linewidth',1);

set(gcf,'color',[1 1 1],'paperpositionmode','auto');
