function volVisIsoSurfaceUpdateSliderPosition(varargin)

% This is a supporting function for the interactive slider driven volume
% visualization recipe, using isoSurfaces, part of Recipe # 3 from chapter 5.
% s is the volumeVisualization_isosurface program instance with the user data. This
% function handles the calls to that instant as appropriate based upon the GUI
% inputs.
% 
    s = get(varargin{1},'Userdata');
    s.deleteIsoSurface();
    v = get(varargin{1},'Value');
    s.plotIsoSurface(v);
 
end