function s = volumeVisualization(x,y,z,v)
%volumeVisualization Engine for choosing any orthogonal plane of review.
%   s = volumeVisualization(X,Y,Z,V) returns a structure 
%   containing information about the visualization of volume
%   data described by X,Y,Z,V.  The fields are:
%          addSlicePlanex -- function handle to add a slice
%                           plane at location x
%          addSlicePlaney -- function handle to add a slice
%                           plane at location y
%          addSlicePlanez -- function handle to add a slice
%                           plane at location z
%   deleteLastSlicePLane -- function handle to delete the
%                           last slice plane added
%                   xMin -- minimum x location for a plane
%                   xMax -- maximum x location for a plane
%                   yMin -- minimum y location for a plane
%                   yMax -- maximum y location for a plane
%                   zMin -- minimum z location for a plane
%                   zMax -- maximum z location for a plane

%% Plot the volume initially
% Draw back and bottom walls
axes('position',[ 0.1169   0.1497    0.6691    0.7697]);
hold on;
hx = slice(x, y, z, v, min(x(:)),       [],       []) ;
hy = slice(x, y, z, v, [],       min(y(:)),       []) ;
% hz = slice(x, y, z, v, [],              [],min(z(:))) ;
% 
% % Make everything look nice
set([hx hy],'FaceColor','interp','EdgeColor','none')
set(hx,'alphadata',squeeze(double(v(end,:,:))),'facealpha','interp'); alim([0 2]);
set(hy,'alphadata',squeeze(double(v(:,end,:))),'facealpha','interp'); alim([0 2]);
% set(hz,'alphadata',squeeze(double(v(:,:,end))),'facealpha','interp'); alim([0 2]);

xlabel('X');ylabel('Y');zlabel('Z')
axis tight
box on
view(-34.5,30)
colormap (jet(128));

s.addSlicePlanex = @addSlicePlanex;
s.deleteLastSlicePlane = @deleteLastSlicePlane;
s.addSlicePlaney = @addSlicePlaney;
s.addSlicePlanez = @addSlicePlanez;

s.xMin = min(x(:));
s.xMax = max(x(:));
s.yMin = min(y(:));
s.yMax = max(y(:));
s.zMin = min(z(:));
s.zMax = max(z(:));

hSlicePlanes = [];
%% Nested Functions
    function addSlicePlanex(xLoc)
    %addSlicePlane   Add a slice plane xLoc.
        newSlicePlane = slice(x, y, z, v, xLoc, [], []);
        hSlicePlanes   = [ hSlicePlanes, newSlicePlane ];
        set(newSlicePlane,'FaceColor'      ,'interp',...
                          'EdgeColor'      ,'none'  ,...
                          'DiffuseStrength',.8          );
    end

    function addSlicePlaney(yLoc)
        %addSlicePlane   Add a slice plane yLoc.
            newSlicePlane = slice(x, y, z, v, [], yLoc, []);
            hSlicePlanes   = [ hSlicePlanes, newSlicePlane ];
            set(newSlicePlane,'FaceColor'      ,'interp',...
                              'EdgeColor'      ,'none'  ,...
                              'DiffuseStrength',.8       );
    end

    function addSlicePlanez(zLoc)
        %addSlicePlane   Add a slice plane xLoc.
            newSlicePlane = slice(x, y, z, v, [], [], zLoc);
            hSlicePlanes   = [ hSlicePlanes, newSlicePlane ];
            set(newSlicePlane,'FaceColor'      ,'interp',...
                              'EdgeColor'      ,'none'  ,...
                              'DiffuseStrength',.8       );
    end

    function deleteLastSlicePlane()
    %deleteLastSlicePlane Delete the last slice plane added.
        if ~isempty(hSlicePlanes)
            delete(hSlicePlanes(end));
            hSlicePlanes = hSlicePlanes(1:end-1);
        end
    end
    
end
