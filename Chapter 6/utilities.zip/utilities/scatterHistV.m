function [mainDataAxes xhistAxes yhistAxes] = scatterHistV(x,y,NbinX,NbinY)

% [mainDataAxes xhistAxes yhistAxes] =
% scatterHistV(x,y,Nbins) makes a two dimensional scatter plot of x versus
% y, along with the individual univariate distributions of both x and y by
% its side. It also takes NbinX and NbinY as the number of bins with which to make
% the histogram.
% It returns the axes handles to the two histograms and the scatter plot,
% so that you can alter the annotations as needed.

set(gcf,'units','normalized','position',[0.2589    0.3296    0.3859    0.5750]);
yhistAxes = axes('position',[0.0596    0.3291    0.2193    0.5859]);
mainDataAxes = axes('position',[0.3492    0.3286    0.5936    0.5860]);
xhistAxes = axes('position',[0.3492    0.0338    0.5869    0.2193]);

axes(mainDataAxes);
scatter(x,y);axis([min(x) max(x) min(y) max(y)]);
[N1, c1]= hist(x,NbinX);
[N2, c2] = hist(y,NbinY);
box on;
axes(xhistAxes);
bar(c1,N1,'facecolor',[.7 .7 .7],'edgecolor',[1 1 1]); 
xlim([min(x) max(x)]);
set(gca,'ydir','reverse','xticklabel',{},'visible','off')
line(get(gca,'xlim'),[0 0],'Color',[0 0 0]);

axes(yhistAxes);
barh(c2,N2,'facecolor',[.7 .7 .7],'edgecolor',[1 1 1]); 
ylim([min(y) max(y)]);
line([0 0],get(gca,'ylim'),'Color',[0 0 0]);
set(gca,'xdir','reverse','yticklabel',{},'visible','off');
