function strArr = strChopper(str,tok)

% this function takes a character string in str and returns an array of strings
% created by splitting the original string str, at the points with the token tok
% 
% example: 
% str = 'abc def ghi jkl mno,pqu';
% strArr = strChopper(str,' ');
% strArr = 
% 
%     'abc'    'def'    'ghi'    'jkl'    'mno,pqu'
% 
i = 0;
while ~isempty(str)
    i = i+ 1;
    [strArr{i} str] = strtok(str,tok);
end
    