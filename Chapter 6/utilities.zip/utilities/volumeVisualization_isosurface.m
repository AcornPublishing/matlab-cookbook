function s = volumeVisualization_isosurface(v,faceColor)
%volumeVisualization Engine for choosing value at which to construct the isosurface.
%   s = volumeVisualization_isosurface(X,Y,Z,V) returns a structure 
%   containing information about the visualization of volume
%   data described by X,Y,Z,V.  The fields are:
%          plotIsoSurface -- function handle to plot isosurface for value v
%        deleteIsoSurface -- function handle to delete the last isosurface
%                           last slice plane added
%                   vMin -- minimum v for the dataset
%                   vMax -- maximum v for the dataset

%% Plot the volume initially
% Draw initial isosurface
axes('position',[ 0.1169   0.1497    0.6691    0.7697]);
hold on;

hiso = patch(isosurface(v,mean(v(:))),...
            'FaceColor',faceColor,...
            'EdgeColor','none');
axis tight
box on
view(-34.5,30)
lightangle(45,30);
lighting phong

s.plotIsoSurface = @plotIsoSurface;
s.deleteIsoSurface = @deleteIsoSurface;

s.vMin = min(v(:));
s.vMax = max(v(:));

hIsoSurfaces = hiso;
%% Nested Functions
    function plotIsoSurface(val)
    
        %plotIsoSurface   at value val
        newIsoSurface = patch(isosurface(v,val),...
            	'FaceColor',faceColor,...
            'EdgeColor','none');
        
        hIsoSurfaces   = [ hIsoSurfaces, newIsoSurface ];
        set(newIsoSurface,...
                          'EdgeColor'      ,'none'  ,...
                          'DiffuseStrength',.8          );
    end

    function deleteIsoSurface()
    %deleteIsoSurface Delete the last isoSurface added.
        if ~isempty(hIsoSurfaces)
            delete(hIsoSurfaces(end));
            hIsoSurfaces = hIsoSurfaces(1:end-1);
        end
    end
    
end
