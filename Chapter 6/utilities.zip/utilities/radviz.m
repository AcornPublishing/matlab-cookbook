function [ux uy] = radviz(data)

% This function accepts a n x m dataset, representing n observation of m
% dimensions each. (The m dimensions should each be scaled between 0 and 1. 
% It will calculate the 2D radial coordinates corresponding to
% the m dimensional data point using a non-linear mapping. The idea is, 
% consider a point in a 2D space, connected to m equally spaced point on 
% some circle with springs. Now, consider each of the m dimensions of the 
% data point as the spring constant for the corresponding springs. Now, 
% consider if the centre point is allowed to move and reach equilibrium position. 
% This would be the mapping of the m dimensional point onto 2D space. In order 
% to determine the location of the data point the sum of the spring forces needs 
% to equal zero. 

sj = linspace(0,360,size(data,2)+1);
xj = cos((pi/180)*sj(1:end-1));
yj = sin((pi/180)*sj(1:end-1));

for i = 1:size(data,1)
    I=find(data(i,:)~=-inf);
    wij = zeros(size(data(i,:)));
    wij(I) = data(i,I)/nansum(data(i,I));
    ux(i) = nansum(wij(I).*xj(I));
    uy(i) = nansum(wij(I).*yj(I));    
end


