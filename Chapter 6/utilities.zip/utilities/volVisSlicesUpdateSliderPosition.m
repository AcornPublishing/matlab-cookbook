function volVisSlicesUpdateSliderPosition(varargin)

% This is a supporting function for the interactive slider driven volume
% visualization recipe, using Slices, part of Recipe # 2 from chapter 5.
% s is the volumeVisualization program instance with the user data. This
% function handles the calls to that instant as appropriate based upon the GUI
% inputs.
% 
    s = get(varargin{1},'Userdata');
    switch(get(varargin{1},'tag'))
        case 'x'            
            s.deleteLastSlicePlane();
            x = get(varargin{1},'Value');
            s.addSlicePlanex(x);
        case 'y'
            s.deleteLastSlicePlane();
            y = get(varargin{1},'Value');
            s.addSlicePlaney(y);            
        case 'z'
            s.deleteLastSlicePlane();
            z = get(varargin{1},'Value');
            s.addSlicePlanez(z);            
    end    
end